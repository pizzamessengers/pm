import React from "react";

const Link = ({ attachment }) => <a href={attachment.url}>{attachment.url}</a>;

export default Link;
