import React, { Component } from "react";
import translate from "./../../../../functions/translate";

export default class UserSettings extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return <div>Crm</div>;
  }
}
