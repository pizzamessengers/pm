import { createContext } from "react";

const CrmContext = createContext();

export default CrmContext;
