<?php

use Faker\Generator as Faker;

$factory->define(App\Dialog::class, function (Faker $faker) {
    return [
        //
    ];
});
