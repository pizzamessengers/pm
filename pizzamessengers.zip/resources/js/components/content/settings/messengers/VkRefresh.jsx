import React from "react";

const VkRefresh = ({ connectDialogs, waitingOn }) => {
  let vkRefresh = () => {
    waitingOn();
    axios.get("api/v1/messengers/vk?api_token=" + apiToken).then(response => {
      if (response.data.success) {
        connectDialogs(response.data.dialogs);
      }
    });
  };

  return (
    <div>
      <button className="main-button" onClick={vkRefresh}>
        {translate("connection.vk.refresh")}
      </button>
    </div>
  );
};

export default VkRefresh;
