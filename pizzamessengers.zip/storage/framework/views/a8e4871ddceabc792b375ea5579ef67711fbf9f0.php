<?php $__env->startSection('content'); ?>
  <div id="root"></div>
  <script>
    let apiToken = <?php echo json_encode($apiToken, 15, 512) ?>,
        socials = <?php echo json_encode($socials, 15, 512) ?>;
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>