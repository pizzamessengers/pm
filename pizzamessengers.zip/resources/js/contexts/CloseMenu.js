import { createContext } from "react";

const CloseMenu = createContext();

export default CloseMenu;
