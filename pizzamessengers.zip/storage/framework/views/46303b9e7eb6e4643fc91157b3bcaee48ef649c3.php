<?php $__env->startSection('content'); ?>
  <div>Hello</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.landing', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>