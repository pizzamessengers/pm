@extends('layouts.landing')

@section('content')
  <div>Hello</div>
@endsection
