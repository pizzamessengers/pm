import React from "react";

const Support = () => (
  <div className="">support</div>
);

export default Support;
