import { createContext } from "react";

const History = createContext();

export default History;
