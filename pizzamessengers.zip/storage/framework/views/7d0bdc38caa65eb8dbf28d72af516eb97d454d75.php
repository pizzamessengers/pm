<?php $__env->startSection('content'); ?>
  <div id="root"></div>
  <script>
    let apiToken  = <?php echo json_encode($apiToken, 15, 512) ?>,
        lang      = <?php echo json_encode($lang, 15, 512) ?>,
        userName  = <?php echo json_encode($userName, 15, 512) ?>,
        crm       = <?php echo json_encode($crm, 15, 512) ?>,
        socials   = <?php echo json_encode($socials, 15, 512) ?>;
  </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.application', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>